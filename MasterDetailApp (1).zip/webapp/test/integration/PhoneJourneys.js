/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"Courses/MasterDetailApp/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"Courses/MasterDetailApp/test/integration/pages/App",
	"Courses/MasterDetailApp/test/integration/pages/Browser",
	"Courses/MasterDetailApp/test/integration/pages/Master",
	"Courses/MasterDetailApp/test/integration/pages/Detail",
	"Courses/MasterDetailApp/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "Courses.MasterDetailApp.view."
	});

	sap.ui.require([
		"Courses/MasterDetailApp/test/integration/NavigationJourneyPhone",
		"Courses/MasterDetailApp/test/integration/NotFoundJourneyPhone",
		"Courses/MasterDetailApp/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});