sap.ui.define([
	"test/unit/model/models",
	"test/unit/model/formatter",
	"test/unit/controller/App.controller",
	"test/unit/controller/ListSelector"
], function() {
	"use strict";
});