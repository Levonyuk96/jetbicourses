sap.ui.define([
	"sap/ui/core/format/DateFormat"
	] , function (dateFormat) {
		"use strict";

		return {

			/**
			 //* Rounds the number unit value to 2 digits
			 //* @public
			 //* @param {string} sValue the number string to be rounded
			 //* @returns {string} sValue with 2 digits rounded
			 //*/
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			},
			creationInfo: function(dDate, sFullName, dDate2) {
				var oDateFormat =dateFormat.getDateTimeInstance({
					formatOptions: {
					style: 'full',
					source: {
					pattern: "yyyy/MM/dd HH:mm",
						relative: true,
					relativeScale: 'auto'
					}
					}
					
				});
				
		
				var sDate = oDateFormat.format(dDate);
				return `${this.getModel("i18n").getResourceBundle().getText("tableNameColumnTitle5")} ${sFullName} ${this.getModel("i18n").getResourceBundle().getText("tOn")} ${sDate}
			`},
							
						radioButtonGroup: function(sValue){
							return(sValue !==null) ? parseInt(sValue,10) -1 : -1;
			}
		};

	}
);